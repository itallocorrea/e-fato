package br.com.puc.efato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EfatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EfatoApplication.class, args);
	}

}
